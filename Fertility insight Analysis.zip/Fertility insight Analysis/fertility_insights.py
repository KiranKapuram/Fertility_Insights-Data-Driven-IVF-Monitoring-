
#import libraries 

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Loading the datasets"""
appointments = pd.read_csv("C:/Users/91837/OneDrive/Desktop/Projects/Fertility insight Analysis/Dataset/ivf_appointments.csv")
equipments = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_equipment.csv")
operational_cost = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_operational_costs.csv")
patient_wait_time = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_patient_wait_times.csv")
performance_kpis = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_performance_kpis.csv")
room_utilization = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_room_utilization.csv")
staff = pd.read_csv(r"C:\Users\91837\OneDrive\Desktop\Projects\Fertility insight Analysis\Dataset\ivf_staff.csv")

# Cleaning Datasets
#Cleaning Appointments Dataset

appointments.head()
appointments.info()
appointments.dtypes

appointments['scheduled_datetime'] = pd.to_datetime(appointments['scheduled_datetime'], format='%d-%m-%Y %H:%M')
appointments['actual_start_time'] = pd.to_datetime(appointments['actual_start_time'], format='%d-%m-%Y %H:%M')
appointments['actual_end_time'] = pd.to_datetime(appointments['actual_end_time'], format='%d-%m-%Y %H:%M')
appointments['created_date'] = pd.to_datetime(appointments['created_date'], format='%d-%m-%Y %H:%M')

appointments.info()
appointments.isna().sum()
appointments['patient_id'].fillna('Unknown', inplace=True)
appointments['doctor_id'].fillna('Unknown', inplace=True)
appointments['room_id'].fillna('Unknown', inplace=True)
appointments['notes'].fillna('No notes', inplace=True)

appointments.info()

appointments.duplicated().sum()
appointments.drop_duplicates(inplace=True)

#scheduled → actual start median gap (in minutes)
start_gap = (
    appointments['actual_start_time']
    - appointments['scheduled_datetime']
).dt.total_seconds() / 60

median_start_gap = start_gap.dropna().median()

#fill missing actual_start_time
appointments.loc[
    appointments['actual_start_time'].isna(),
    'actual_start_time'
] = (
    appointments['scheduled_datetime']
    + pd.to_timedelta(median_start_gap, unit='m')
)
# Create a duration column only for completed appointments
appointments['actual_duration_minutes'] = (
    (appointments['actual_end_time'] - appointments['actual_start_time']).dt.total_seconds() / 60
)

# actual start → actual end median duration (in minutes)
end_gap = (
    appointments['actual_end_time']
    - appointments['actual_start_time']
).dt.total_seconds() / 60

median_duration = end_gap.dropna().median()

# fill missing actual_end_time
appointments.loc[
    appointments['actual_end_time'].isna(),
    'actual_end_time'
] = (
    appointments['actual_start_time']
    + pd.to_timedelta(median_duration, unit='m')
)
     
#fill actual_duration_mins
appointments.loc[
    appointments['actual_duration_minutes'].isna(),
    'actual_duration_minutes'
] = (
    (appointments['actual_end_time']
     - appointments['actual_start_time'])
    .dt.total_seconds() / 60
)

# For non-completed, this will stay Null, which is correct.

appointments.info()
appointments.head()

#"""**Cleaning Equipment Dataset**"""

equipments.isna().sum()
equipments.info()
equipments.shape
equipments.dtypes


equipments['purchase_date'] = pd.to_datetime(equipments['purchase_date'], format='%d-%m-%Y')
equipments['last_maintenance_date'] = pd.to_datetime(equipments['last_maintenance_date'], format='%d-%m-%Y', errors='coerce')
equipments['next_maintenance_due'] = pd.to_datetime(equipments['next_maintenance_due'], format='%d-%m-%Y', errors='coerce')

equipments['serial_number'].fillna('Unknown', inplace=True)
equipments['maintenance_diff'] = (equipments['next_maintenance_due'] - equipments['last_maintenance_date']).dt.days


median_diff = equipments['maintenance_diff'].dropna().median()


equipments['last_maintenance_date'] = (
    equipments
    .groupby(['model', 'equipment_type'])['last_maintenance_date']
    .transform(lambda x: x.fillna(x.median()))
)

equipments['last_maintenance_date'] = equipments['last_maintenance_date'].fillna(
    equipments['purchase_date']
)

# Fill missing next maintenance dates using the median difference
equipments.loc[
    equipments['next_maintenance_due'].isnull(),
    'next_maintenance_due'
] = (
    equipments['last_maintenance_date'] + pd.Timedelta(days=median_diff)
)
# Drop the temporary difference column
equipments.drop(columns=['maintenance_diff'], inplace=True)

equipments.info()

equipments['serial_number'] = equipments['serial_number'].fillna('Unknown')




equipments.drop_duplicates(inplace=True)
equipments.info()
plt.hist(equipments['purchase_cost'], bin=30)
plt.boxplot(equipments['purchase_cost'])
equipments.describe()


"""**Cleaning Operation Costs**"""

operational_cost.head()
operational_cost.info()


operational_cost.dtypes
operational_cost['date'] = pd.to_datetime(operational_cost['date'])

operational_cost.info()
operational_cost.isna().sum()
operational_cost['vendor'] = operational_cost['vendor'].fillna('Unknown')
operational_cost['invoice_number'] = operational_cost['invoice_number'].fillna('Unknown')

operational_cost.duplicated().sum()
operational_cost.drop_duplicates(inplace=True)

operational_cost.info()
operational_cost.head()
operational_cost.isna().sum().sum()


#patient wait time data cleaning 
patient_wait_time.head()
patient_wait_time.info()
patient_wait_time.shape

patient_wait_time['scheduled_time'] = pd.to_datetime(patient_wait_time['scheduled_time'],format="%d-%m-%Y %H:%M" )
patient_wait_time['arrival_time'] = pd.to_datetime(patient_wait_time['arrival_time'],format="%d-%m-%Y %H:%M" )
patient_wait_time['called_time'] = pd.to_datetime(patient_wait_time['called_time'],format="%d-%m-%Y %H:%M" )

patient_wait_time.isna().sum()
patient_wait_time['complaint_logged'].fillna(0, inplace=True)

median_score = patient_wait_time['patient_satisfaction_score'].median()
patient_wait_time['patient_satisfaction_score'].fillna(median_score, inplace=True)

patient_wait_time.dropna(subset=['appointment_id'], inplace=True)
patient_wait_time.duplicated().sum()


"""**Data cleaning for Performance Kpi**"""

performance_kpis.head()
performance_kpis.info()

performance_kpis.dtypes
performance_kpis['month_year'] = pd.to_datetime(performance_kpis['month_year'],format= '%Y-%m')

performance_kpis.isna().sum()
performance_kpis['kpi_value'] = performance_kpis.groupby(['department', 'kpi_name'])['kpi_value'].transform(
    lambda x: x.fillna(x.median())
)

performance_kpis.duplicated().sum()
performance_kpis.drop_duplicates(inplace=True)
performance_kpis.info()

"""**Data Cleaning of Room utization **"""

room_utilization.head()
room_utilization.info()
room_utilization.dtypes

room_utilization['start_time'] = pd.to_datetime(room_utilization['start_time'], errors='coerce')
room_utilization['end_time'] = pd.to_datetime(room_utilization['end_time'], errors='coerce')

room_utilization['start_time'] = pd.to_datetime(room_utilization['start_time'].astype(str), format='mixed')
room_utilization['end_time'] = pd.to_datetime(room_utilization['end_time'].astype(str), format='mixed')

room_utilization.duplicated().sum()
room_utilization.drop_duplicates(inplace=True)

room_utilization.isna().sum()
room_utilization['staff_id_assigned'].fillna('Unknown', inplace=True)
room_utilization['patient_id'].fillna('Unknown', inplace=True)

room_utilization.info()
room_utilization.head()

print("Initial data types of relevant columns:") 
print(room_utilization[['usage_date', 'start_time', 'end_time']].dtypes)

room_utilization['usage_date'] = pd.to_datetime(room_utilization['usage_date'])

room_utilization.info()
room_utilization.head()
room_utilization['is_over_capacity'] = room_utilization['actual_occupants'] > room_utilization['room_capacity']


"""**staff Data Cleaning **"""

staff.head()
staff.info()

staff.dtypes
staff['hire_date'] = pd.to_datetime(staff['hire_date'], errors='coerce')
staff['certification_expiry'] = pd.to_datetime(staff['certification_expiry'], errors='coerce')
staff['shift_start_time'] = pd.to_datetime(staff['shift_start_time'], errors='coerce')
staff['shift_end_time'] = pd.to_datetime(staff['shift_end_time'], errors='coerce')
staff['phone'] = staff['phone'].astype(str)

staff.isna().sum()
staff['email'].fillna('Unknown', inplace=True)
staff['certification_expiry'].fillna('N/A', inplace=True)

staff['hire_date'] = (
    staff
    .groupby('specialty')['hire_date']
    .transform(lambda x: x.fillna(x.median()))
)

staff['hire_date'] = staff['hire_date'].fillna(
    staff['hire_date'].min()
)
staff.duplicated().sum()
staff.drop_duplicates(inplace=True)

staff['certification_expiry'] = (
    staff
    .groupby('specialty')['certification_expiry']
    .transform(lambda x: x.fillna(x.median()))
)

# fallback: derive expiry using typical validity period from hire_date
validity_days = (
    (staff['certification_expiry'] - staff['hire_date'])
    .dt.days
    .dropna()
    .median()
)

staff.loc[
    staff['certification_expiry'].isna(),
    'certification_expiry'
] = staff['hire_date'] + pd.to_timedelta(validity_days, unit='D')


# Fix negative phone numbers before converting to string
staff['phone'] = staff['phone'].astype(str).str.replace('-', '')
staff.info()
staff.head()



# Univariant Analysis
 
#Appointments Table 
appointments['appointment_id'].mode()

appointments['patient_id'].mode()

appointments['doctor_id'].mode()

appointments['department'].mode()

appointments['appointment_type'].mode()

appointments['scheduled_datetime'].mode()

appointments['scheduled_duration_minutes'].mean()
appointments['scheduled_duration_minutes'].median()
appointments['scheduled_duration_minutes'].std()
appointments['scheduled_duration_minutes'].var()
appointments['scheduled_duration_minutes'].skew()
appointments['scheduled_duration_minutes'].kurt()


appointments['status'].mode()

appointments['created_date'].mode()

appointments['booking_channel'].mode()

appointments['priority'].mode()

appointments['room_id'].mode()

appointments['notes'].mode()

#Univariant analysis on Equipment table 

equipments['equipment_type'].mode()

equipments['brand'].mode()

equipments['model'].mode()

equipments['room_id'].mode()

equipments['status'].mode()

equipments['purchase_date'].mode()

equipments['purchase_cost'].mean()
equipments['purchase_cost'].median()
equipments['purchase_cost'].std()
equipments['purchase_cost'].var()
equipments['purchase_cost'].skew()
equipments['purchase_cost'].kurt()

equipments['last_maintenance_date'].mode()

equipments['next_maintenance_due'].mode()

equipments['utilization_hours_per_day'].mean()
equipments['utilization_hours_per_day'].median()
equipments['utilization_hours_per_day'].mode()
equipments['utilization_hours_per_day'].std()
equipments['utilization_hours_per_day'].var()
equipments['utilization_hours_per_day'].skew()
equipments['utilization_hours_per_day'].kurt()

equipments['department'].mode()


#Univariant analysis on Operational Cost
operational_cost['date'].mode()

operational_cost['category'].mode()

operational_cost['subcategory'].mode()

operational_cost['amount'].mean()
operational_cost['amount'].median()
operational_cost['amount'].std()
operational_cost['amount'].var()
operational_cost['amount'].skew()
operational_cost['amount'].kurt()

operational_cost['vendor'].mode()

operational_cost['department'].mode()

operational_cost['budget_allocated'].mean()
operational_cost['budget_allocated'].median()
operational_cost['budget_allocated'].std()
operational_cost['budget_allocated'].var()
operational_cost['budget_allocated'].skew()
operational_cost['budget_allocated'].kurt()

operational_cost['approval_status'].mode()

operational_cost['payment_status'].mode()


#Univariant analysis on patient_wait_time
patient_wait_time['appointment_id'].mode()
patient_wait_time['patient_id'].mode()

patient_wait_time['scheduled_time'].mode()
patient_wait_time['arrival_time'].mode()
patient_wait_time['called_time'].mode()

patient_wait_time['wait_time_minutes'].mean()
patient_wait_time['wait_time_minutes'].median()
patient_wait_time['wait_time_minutes'].std()
patient_wait_time['wait_time_minutes'].var()
patient_wait_time['wait_time_minutes'].skew()
patient_wait_time['wait_time_minutes'].kurt()

patient_wait_time['department'].mode()
patient_wait_time['day_of_week'].mode()
patient_wait_time['time_of_day_category'].mode()

patient_wait_time['patient_satisfaction_score'].mean()
patient_wait_time['patient_satisfaction_score'].median()
patient_wait_time['patient_satisfaction_score'].mode()
patient_wait_time['patient_satisfaction_score'].std()
patient_wait_time['patient_satisfaction_score'].var()
patient_wait_time['patient_satisfaction_score'].skew()
patient_wait_time['patient_satisfaction_score'].kurt()

#Univariant analysis on performance_kpis
performance_kpis['month_year'].mode()

performance_kpis['department'].mode()

performance_kpis['kpi_value'].mean()
performance_kpis['kpi_value'].median()
performance_kpis['kpi_value'].std()
performance_kpis['kpi_value'].var()
performance_kpis['kpi_value'].skew()
performance_kpis['kpi_value'].kurt()


performance_kpis['target_value'].mean()
performance_kpis['target_value'].median()
performance_kpis['target_value'].std()
performance_kpis['target_value'].var()
performance_kpis['target_value'].skew()
performance_kpis['target_value'].kurt()

performance_kpis['unit'].mode()
performance_kpis['trend'].mode()
performance_kpis['benchmark_comparison'].mode()

#Univariant analysis on room_utilization
room_utilization['room_id'].mode()

room_utilization['room_type'].mode()

room_utilization['usage_date'].mode()

room_utilization['duration_minutes'].mean()
room_utilization['duration_minutes'].median()
room_utilization['duration_minutes'].std()
room_utilization['duration_minutes'].var()
room_utilization['duration_minutes'].skew()
room_utilization['duration_minutes'].kurt()

room_utilization['staff_id_assigned'].mode()

room_utilization['patient_id'].mode()

room_utilization['usage_type'].mode()

room_utilization['occupancy_rate'].mean()
room_utilization['occupancy_rate'].median()
room_utilization['occupancy_rate'].std()
room_utilization['occupancy_rate'].var()
room_utilization['occupancy_rate'].skew()
room_utilization['occupancy_rate'].kurt()

room_utilization['room_capacity'].mean()
room_utilization['room_capacity'].median()
room_utilization['room_capacity'].std()
room_utilization['room_capacity'].var()
room_utilization['room_capacity'].skew()
room_utilization['room_capacity'].kurt()

room_utilization['actual_occupants'].mean()
room_utilization['actual_occupants'].median()
room_utilization['actual_occupants'].std()
room_utilization['actual_occupants'].var()
room_utilization['actual_occupants'].skew()
room_utilization['actual_occupants'].kurt()

#Univariant analysis on staff

staff['specialty'].mode()

staff['department'].mode()

staff['employment_status'].mode()

staff['experience_years'].mean()
staff['experience_years'].median()
staff['experience_years'].std()
staff['experience_years'].var()
staff['experience_years'].kurt()
staff['experience_years'].skew()


staff['weekly_hours'].mean()
staff['weekly_hours'].median()
staff['weekly_hours'].std()
staff['weekly_hours'].var()
staff['weekly_hours'].kurt()
staff['weekly_hours'].skew()


staff['hourly_rate'].mean()
staff['hourly_rate'].median()
staff['hourly_rate'].std()
staff['hourly_rate'].var()
staff['hourly_rate'].kurt()
staff['hourly_rate'].skew()


#Bivariant Analysis 

appointments['scheduled_duration_minutes'].corr(appointments['actual_duration_minutes'])
appointments['scheduled_duration_minutes'].cov(appointments['actual_duration_minutes'])

staff['experience_years'].corr(patient_wait_time['wait_time_minutes'])
staff['experience_years'].cov(patient_wait_time['wait_time_minutes'])

staff['experience_years'].corr(patient_wait_time['patient_satisfaction_score'])
staff['experience_years'].cov(patient_wait_time['patient_satisfaction_score'])

staff['experience_years'].corr(performance_kpis['kpi_value'])
staff['experience_years'].cov(performance_kpis['kpi_value'])

patient_wait_time['wait_time_minutes'].corr(patient_wait_time['patient_satisfaction_score'])
patient_wait_time['wait_time_minutes'].cov(patient_wait_time['patient_satisfaction_score'])

patient_wait_time['wait_time_minutes'].corr(patient_wait_time['patient_satisfaction_score'])
patient_wait_time['wait_time_minutes'].cov(patient_wait_time['patient_satisfaction_score'])

patient_wait_time['wait_time_minutes'].corr(performance_kpis['kpi_value'])
patient_wait_time['wait_time_minutes'].cov(performance_kpis['kpi_value'])

operational_cost['amount'].corr(performance_kpis['kpi_value'])
operational_cost['amount'].cov(performance_kpis['kpi_value'])


#import this mysql 
from sqlalchemy import create_engine
from urllib.parse import quote

#Defining the variables 
user = 'root'
pw = quote('root')
db = 'fertility_insights'

engine = create_engine(f'mysql+pymysql://{user}:{pw}@localhost/{db}')
appointments.to_sql('appointments', con=engine, if_exists = 'replace', chunksize=1000, index= False)
operational_cost.to_sql('operational_cost', con=engine, if_exists ='replace', chunksize= 100, index=False)
equipments.to_sql('equipments', con=engine, if_exists ='replace', chunksize= 100, index=False)
patient_wait_time.to_sql('patient_wait_time', con=engine, if_exists ='replace', chunksize= 100, index=False)
performance_kpis.to_sql('performance_kpis', con=engine, if_exists ='replace', chunksize= 100, index=False)
room_utilization.to_sql('room_utilization', con=engine, if_exists ='replace', chunksize= 100, index=False)
staff.to_sql('staff', con=engine, if_exists ='replace', chunksize= 100, index=False)
#Done
