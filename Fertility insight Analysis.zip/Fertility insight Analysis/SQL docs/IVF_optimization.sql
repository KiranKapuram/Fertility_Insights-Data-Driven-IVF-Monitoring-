create database fertility_insights;
use fertility_insights;

SELECT * FROM appointments;
SELECT * FROM equipments;
SELECT * FROM operational_cost;
SELECT * FROM patient_wait_time;
SELECT * FROM performance_kpis;
SELECT * FROM room_utilization;
SELECT * FROM staff;



/* total number of appointment */
SELECT * FROM appointments;
SELECT COUNT(appointment_id) as total_no_of_appointments 
FROM appointments ;  

/*total no of patients */
SELECT COUNT( DISTINCT patient_id) AS total_patients 
FROM appointments;

/*repeated patients */
SELECT COUNT(patient_id) - COUNT( DISTINCT patient_id) as total_no_of_appointments 
FROM appointments;

/*Total no. of docters*/
SELECT COUNT(DISTINCT doctor_id) AS total_no_of_docters
FROM appointments;

/* Doctors in each department*/
SELECT department, appointment_type, COUNT( DISTINCT doctor_id) as total_no_of_doctors
FROM appointments
GROUP BY department,appointment_type
ORDER BY total_no_of_doctors;

/* the departments these doctors are working */
SELECT DISTINCT department AS departments
FROM appointments;

/* appointments  for each department*/
SELECT department, COUNT(appointment_id) as total_appointmets
FROM appointments
GROUP BY department
ORDER BY  COUNT(appointment_id);

/* no of cases in each type of appointment*/
SELECT appointment_type, COUNT(appointment_id) as total_appointments
FROM appointments
GROUP BY appointment_type
ORDER BY COUNT(appointment_id) DESC ;

/* cases throught the booking channels */
SELECT booking_channel, COUNT(appointment_id) as total_bookings
FROM appointments
GROUP BY booking_channel
ORDER BY COUNT(appointment_id) DESC;  


/* cases based on the priority*/
SELECT priority, COUNT(appointment_id) as total_cases
FROM appointments
GROUP BY priority
ORDER BY  COUNT(appointment_id) DESC;  


/*appointment_type that consistently exceeds its scheduled_duration_minutes*/
SELECT 
    appointment_type,
    ROUND(AVG(scheduled_duration_minutes), 1) AS avg_scheduled,
    ROUND(AVG(TIMESTAMPDIFF(MINUTE, actual_start_time, actual_end_time)), 1) AS avg_actual,
    ROUND(AVG(TIMESTAMPDIFF(MINUTE, actual_start_time, actual_end_time)) - AVG(scheduled_duration_minutes), 1) AS variance_minutes
FROM appointments
WHERE status = 'Completed'
GROUP BY appointment_type
ORDER BY variance_minutes DESC;

/*total volume of "Cancelled" and "No-Show" appointments per booking_channel*/
SELECT 
    booking_channel,
    COUNT(CASE WHEN status IN ('Cancelled', 'No-Show') THEN 1 END) AS failed_volume,
    COUNT(*) AS total_appointments,
    ROUND(COUNT(CASE WHEN status IN ('Cancelled', 'No-Show') THEN 1 END) * 100.0 / COUNT(*), 2) AS failure_rate_percent
FROM appointments
GROUP BY booking_channel
ORDER BY failure_rate_percent DESC;

/*Which doctor_id has the highest volume of "Cancelled" appointments*/
select * from appointments;
SELECT doctor_id, COUNT(appointment_id) as appointments_cancelled
FROM appointments
WHERE status= 'Cancelled'
GROUP BY doctor_id 
ORDER BY COUNT(appointment_id) DESC;

/*Which room_id is used most frequently for "High" priority appointments*/
SELECT room_id, COUNT(appointment_id) AS total_appointments
FROM appointments
WHERE priority = 'High'
GROUP BY room_id
ORDER BY COUNT(appointment_id) DESC;

-- Equipment 
/*Which equipment types have the highest average*/
SELECT 
    equipment_type, 
    ROUND(AVG(utilization_hours_per_day), 1) AS avg_daily_hours,
    COUNT(*) AS total_units
FROM equipments
GROUP BY equipment_type
ORDER BY avg_daily_hours DESC;
SELECT * FROM equipments;

/*Which departments have the most equipment currently in "Maintenance" or "Broken" status*/
SELECT 
    department, 
    COUNT(*) AS troubled_equipment_count
FROM equipments
WHERE status IN ('Broken', 'Maintenance')
GROUP BY department
ORDER BY troubled_equipment_count DESC;

/*total investment (purchase_cost) in equipment that is currently "Retired" or "Broken"*/
SELECT 
    status, 
    COUNT(*) AS unit_count,
    ROUND(SUM(purchase_cost), 2) AS total_asset_value
FROM equipments
WHERE status IN ('Broken', 'Retired')
GROUP BY status;

-- Operational Cost
/*which category is using more funds than allocated Budget  */
SELECT * FROM operational_cost;
SELECT 
    category, 
    ROUND(SUM(budget_allocated),2) AS total_budget, 
    ROUND(SUM(amount),2) AS actual_spend,
    ROUND(SUM(amount) - SUM(budget_allocated), 2) AS variance
FROM operational_cost
GROUP BY category
HAVING variance >0
ORDER BY variance DESC;

/*Who are our top 5 vendors by total spend*/
SELECT 
    vendor, 
    COUNT(cost_id) AS invoice_count,
    ROUND(SUM(amount), 2) AS total_spent
FROM operational_cost
WHERE vendor IS NOT NULL
GROUP BY vendor
ORDER BY total_spent DESC
LIMIT 5;

/*How much money is tied up in "Overdue" or "Due" payments*/
SELECT 
    payment_status, 
    COUNT(*) AS record_count,
    ROUND(SUM(amount), 2) AS total_amount
FROM operational_cost
GROUP BY payment_status;

/*Which department has the highest total operational spend*/
SELECT 
    department, 
    ROUND(SUM(amount), 2) AS total_spend
FROM operational_cost
GROUP BY department
ORDER BY total_spend DESC;

--  ROOM utlization table Analysis
/*How often does the actual_occupants exceed the room_capacity*/
SELECT 
    room_type, 
    COUNT(*) AS over_capacity_incidents
FROM room_utilization
WHERE actual_occupants > room_capacity
GROUP BY room_type
ORDER BY over_capacity_incidents DESC;

/*the average duration for "Cleaning", "Setup", and "Maintenance" compared to "Appointment"*/
SELECT 
    usage_type, 
    COUNT(*) AS usage_count,
    ROUND(AVG(duration_minutes), 1) AS avg_duration_mins
FROM room_utilization
GROUP BY usage_type
ORDER BY avg_duration_mins DESC;

/*Which room types spend the most total minutes in "Non-Revenue" statuses*/
SELECT 
    room_type, 
    SUM(duration_minutes) AS total_non_revenue_mins
FROM room_utilization
WHERE usage_type IN ('Cleaning', 'Maintenance', 'Setup')
GROUP BY room_type
ORDER BY total_non_revenue_mins DESC;

/*Which rooms have an occupancy_rate below 50% while being used for "Appointments"*/
SELECT 
    room_id, 
    room_type, 
    ROUND(AVG(occupancy_rate), 2) AS avg_occupancy
FROM room_utilization
WHERE usage_type = 'Appointment'
GROUP BY room_id, room_type
HAVING avg_occupancy < 0.50;

/*Which staff members have an expired certification_expiry date*/
SELECT staff_id, CONCAT(first_name+' '+last_name) as full_name
FROM staff
WHERE STR_TO_DATE(certification_expiry, '%d-%m-%Y') < '2025-12-16';

/*Which specialty or department has the highest total labor cost (hourly rate * total staff)*/
SELECT
    specialty,
    COUNT(staff_id) AS total_staff,
    ROUND(SUM(hourly_rate), 2) AS total_hourly_cost
FROM staff
GROUP BY specialty
ORDER BY total_hourly_cost DESC;

/*What is the average number of experience_years in each department*/
SELECT department, AVG(experience_years) AS avg_exp, COUNT(staff_id) as no_of_staff
FROM staff
GROUP BY department
ORDER BY avg_exp DESC;

SELECT * FROM patient_wait_time;
/* average rating by patient for each department */
SELECT department,ROUND(AVG(patient_satisfaction_score),2) as avg_dept_satisfaction_score
FROM patient_wait_time
GROUP BY department
ORDER BY avg_dept_satisfaction_score ASC;

/*Which department has the largest negative gap between their 
actual kpi_value and their target_value for the 'Treatment Success Rate */
SELECT
    department,
    ROUND(AVG(kpi_value), 2) AS avg_success_rate,
    ROUND(AVG(target_value), 2) AS avg_target_rate,
    ROUND(AVG(target_value) - AVG(kpi_value), 2) AS success_gap
FROM performance_kpis
WHERE kpi_name = 'Treatment Success Rate'
GROUP BY department
ORDER BY success_gap DESC;

/*Which department has the highest average 'Cost Per Patient'*/
SELECT
    department,
    ROUND(AVG(kpi_value), 2) AS avg_cost_per_patient,
    ROUND(AVG(target_value), 2) AS avg_target_cost
FROM performance_kpis
WHERE kpi_name = 'Cost Per Patient'
GROUP BY department
ORDER BY avg_cost_per_patient DESC;

/*Which KPIs have a 'Volatile' trend status*/
SELECT
    kpi_name,
    COUNT(*) AS volatile_count
FROM performance_kpis
WHERE trend = 'Volatile'
GROUP BY kpi_name
ORDER BY volatile_count DESC;

/*What is the average kpi_value for 'Revenue per Patient' across the entire clinic*/
SELECT
    ROUND(AVG(kpi_value), 2) AS average_revenue_per_patient
FROM performance_kpis
WHERE kpi_name = 'Revenue per Patient';